package net.javaguides.arun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBackend1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
