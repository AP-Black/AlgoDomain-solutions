package net.javaguides.arun.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.javaguides.arun.model.Customer;


public interface CustomerRepository extends JpaRepository<Customer, Long> {

}
