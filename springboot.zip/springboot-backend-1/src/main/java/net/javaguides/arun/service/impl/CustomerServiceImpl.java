package net.javaguides.arun.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.javaguides.arun.exception.ResourceNotFoundException;
import net.javaguides.arun.model.Customer;
import net.javaguides.arun.repository.CustomerRepository;
import net.javaguides.arun.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService 
{
	private CustomerRepository customerRepository;
	
	@Autowired
	public CustomerServiceImpl(CustomerRepository customerRepository) {
		super();
		this.customerRepository = customerRepository;
	}


	@Override
	public Customer saveCustomer(Customer customer) 
	{
		return customerRepository.save(customer);
	}


	@Override
	public List<Customer> getAllCustomers() {
		return customerRepository.findAll();
	}


	@Override
	public Customer getCustomerById(long id) {
		Optional<Customer> customer = customerRepository.findById(id);
//		if(customer.isPresent())
//		{
//			return customer.get();
//		}
//		else
//		{
//			throw new ResourceNotFoundException("Customer", "Id", id);
//		}
		return customerRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Customer", "Id", id));
	}


	@Override
	public Customer UpdateCustomer(Customer customer, long id) {
		
		//we need to check whether customer with given id is exist in table or not
		Customer existingCustomer = customerRepository.findById(id).orElseThrow(
				() -> new ResourceNotFoundException("Customer", "Id", id)); 
		
		existingCustomer.setFirstName(customer.getFirstName());
		existingCustomer.setLastName(customer.getLastName());
		existingCustomer.setEmail(customer.getEmail());
		existingCustomer.setPhone_no(customer.getPhone_no());
		existingCustomer.setAge(customer.getAge());
		existingCustomer.setGender(customer.getGender());
		existingCustomer.setAddress(customer.getAddress());
		existingCustomer.setPincode(customer.getPincode());
		
		//save existing customer to db
		customerRepository.save(existingCustomer);
		return existingCustomer;
	}


	@Override
	public void deleteCustomer(long id) 
	{
		//check whether the customer exist in table or not
		customerRepository.findById(id).orElseThrow(
				() -> new ResourceNotFoundException("Customer", "Id", id));
		customerRepository.deleteById(id);
	}

}
